int blackwhitelist_load_list(const char *filename);
int blackwhitelist_check_hostname(const char *host_addr, size_t host_len);
