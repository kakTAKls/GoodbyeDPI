int service_register();
void service_main(int argc, char *argv[]);
void service_controlhandler(DWORD request);
